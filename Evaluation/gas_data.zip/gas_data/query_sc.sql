SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||113648
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 7||6773
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||264203
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||131808
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||351332
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||275106
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 6||12156
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||45248
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||30311
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||1465
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||178471
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||151933
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||162933
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||17189
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||256550
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||99321
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||79376
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||212501
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||61983
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||12849
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 7 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||1463
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||717
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||336288
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||61253
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 6||7081
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 5||33294
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||158969
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||184596
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 9||7889
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 7 AND Temperature <= 28 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||15479
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||118514
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||34864
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 8 AND R5 >= 5 AND R5 <= 10 AND R7 >= 4 AND R7 <= 7||811
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 8 AND Flow_rate <= 39 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 5||2226
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||125007
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||101605
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||197858
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 3 AND Humidity <= 27 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||7638
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||4788
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||179020
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 8||1235
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||105150
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 9 AND Flow_rate <= 40 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||3795
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 7||9971
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||1321
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||87115
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||4550
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||323887
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||3807
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||269
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||212501
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||221358
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||16274
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 6||1710
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||74231
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||344712
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||1650
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||418
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||66334
SELECT COUNT(*) FROM climate WHERE Temperature >= 7 AND Temperature <= 28 AND Flow_rate >= 9 AND Flow_rate <= 40 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||147
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||323887
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 6||7182
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||167504
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Temperature >= 2 AND Temperature <= 23 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||15073
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||144724
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 11 AND Flow_rate <= 42 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||6
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||31998
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||115585
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||46664
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||5629
SELECT COUNT(*) FROM climate WHERE Humidity >= 6 AND Humidity <= 30 AND Temperature >= 4 AND Temperature <= 25 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 5 AND R1 <= 10 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||5542
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||53398
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||20559
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 7 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 7||9051
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||15444
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||263279
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||214248
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||203609
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||344712
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||31710
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||60650
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 9||681
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||333918
SELECT COUNT(*) FROM climate WHERE Humidity >= 10 AND Humidity <= 34 AND Temperature >= 6 AND Temperature <= 27 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||1617
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||1512
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70798
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170147
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||118514
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||100823
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||843
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||16274
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||11
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||170147
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||55468
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||110519
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||4592
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||163286
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||178581
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||323887
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||213978
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||6452
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||10155
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||144724
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||72471
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||355286
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||190748
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||334100
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||113648
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 8 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||285
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||192895
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||289260
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||12390
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||110080
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||53638
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||341
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 6||3877
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||104343
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||17683
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||213978
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||108914
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 9||504
SELECT COUNT(*) FROM climate WHERE Temperature >= 6 AND Temperature <= 27 AND Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||18786
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 7||2799
SELECT COUNT(*) FROM climate WHERE Temperature >= 6 AND Temperature <= 27 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||49072
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||2837
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||192895
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 5||105587
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||91931
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 7||11865
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||447
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 6||68630
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||102325
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 9||6150
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 6||24359
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 8||385
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 5||21301
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||216714
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||19351
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||333918
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 9 AND R5 >= 5 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||2781
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||190525
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||131911
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 4 AND R1 <= 9 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 7||30207
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||1977
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||162494
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||5031
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||31707
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||77925
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||100823
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 7||2055
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 6||22184
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||174141
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||233779
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 9 AND R5 >= 5 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||15600
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||1003
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 5||4012
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 7||68617
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 5||21851
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||256550
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||12172
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||65315
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||40342
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||158326
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||114207
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 7 AND R5 >= 5 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||2240
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Humidity >= 4 AND Humidity <= 28 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 9 AND R7 >= 4 AND R7 <= 9||611
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Humidity >= 4 AND Humidity <= 28 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||216
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||504
SELECT COUNT(*) FROM climate WHERE Time >= 8 AND Time <= 20 AND Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||5978
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||3913
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||85296
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||2020
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||217918
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||61983
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||7837
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||2185
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 4 AND R1 <= 9 AND R5 >= 3 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||7172
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||221358
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 8 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||539
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||264203
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||823
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 5 AND R7 <= 8||1452
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||135897
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||257016
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||155627
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||25113
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 8 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||250
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||7420
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||108929
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||1017
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||216714
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||334100
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||61983
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||256145
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||61983
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||144724
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||11359
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110519
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||167504
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||108929
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||79369
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||162494
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||82308
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||164215
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||33392
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||234218
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||24508
SELECT COUNT(*) FROM climate WHERE Humidity >= 6 AND Humidity <= 30 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||79539
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||100823
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||124385
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||144724
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||204313
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||5212
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||103904
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 5||49865
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||53191
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||203609
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||26940
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Humidity >= 0 AND Humidity <= 24 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||1049
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||34167
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||53466
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||226176
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||3
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 6||3583
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||14067
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||118953
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||62397
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||109353
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||197858
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||185328
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||137336
SELECT COUNT(*) FROM climate WHERE Humidity >= 10 AND Humidity <= 34 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||25552
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||6953
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||40183
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 2 AND Temperature <= 23 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||9967
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170147
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||564
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||355286
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||109353
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||24111
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||234218
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||49082
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 6 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||7271
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||344712
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Humidity >= 3 AND Humidity <= 27 AND R1 >= 4 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 8||12815
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||110519
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||256145
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Humidity >= 5 AND Humidity <= 29 AND R1 >= 6 AND R1 <= 10 AND R5 >= 6 AND R5 <= 11 AND R7 >= 5 AND R7 <= 10||584
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||50796
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70798
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||162510
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||19830
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||1195
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 6||32427
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||114443
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 6 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||6773
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||331
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||213978
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||158326
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||150520
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||114443
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||155627
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||41212
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||100823
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||31173
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 7||32427
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||84524
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||257016
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||114003
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||275651
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||41881
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||94352
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||234218
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||26949
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||203609
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||88136
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||108800
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 13 AND Flow_rate <= 44 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||834
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 3 AND Temperature <= 24 AND Flow_rate >= 14 AND Flow_rate <= 45 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||222
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||57454
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 6||693
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||109353
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||7420
SELECT COUNT(*) FROM climate WHERE Time >= 6 AND Time <= 18 AND Humidity >= 9 AND Humidity <= 33 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 10||197
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70798
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||24856
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 4 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 6||22269
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||334100
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||2702
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110519
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||224297
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||54493
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||80784
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||113440
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||58708
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||109353
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||54526
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||131808
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||56445
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||67393
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||54526
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||38988
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||334100
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||256145
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 7||105150
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 5 AND R7 >= 3 AND R7 <= 8||4111
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||98897
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 7 AND R7 >= 5 AND R7 <= 10||1463
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 5 AND R1 <= 9 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||1406
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||125007
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||194826
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||334100
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||155541
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 5 AND R1 <= 9 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||14354
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||230448
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||125441
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||275106
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||1036
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||103904
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||62397
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||224297
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 5||17189
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 3 AND R7 <= 6||17048
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||439
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||4676
SELECT COUNT(*) FROM climate WHERE Temperature >= 5 AND Temperature <= 26 AND R1 >= 5 AND R1 <= 9 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 8||1400
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||23415
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||336288
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||151933
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||118514
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||170586
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||504
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 5||26842
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||229000
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||135459
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||230448
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||104343
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||66631
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||216714
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||504
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND R1 >= 5 AND R1 <= 9 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||1393
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 9 AND R5 >= 5 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||1932
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||4479
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||313878
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 5||3807
SELECT COUNT(*) FROM climate WHERE Temperature >= 5 AND Temperature <= 26 AND R1 >= 5 AND R1 <= 8 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||1224
SELECT COUNT(*) FROM climate WHERE Temperature >= 5 AND Temperature <= 26 AND Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 6 AND R1 <= 10 AND R5 >= 6 AND R5 <= 11 AND R7 >= 5 AND R7 <= 8||622
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||79333
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||275651
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||24949
SELECT COUNT(*) FROM climate WHERE Temperature >= 4 AND Temperature <= 25 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||1767
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||2338
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 5 AND R7 >= 3 AND R7 <= 8||4019
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||192895
SELECT COUNT(*) FROM climate WHERE Time >= 7 AND Time <= 19 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||1546
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||56871
SELECT COUNT(*) FROM climate WHERE Temperature >= 6 AND Temperature <= 27 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||4277
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||233779
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||45446
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||162510
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||223647
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||1278
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||223858
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||313878
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||203609
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||214248
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 8 AND R7 >= 5 AND R7 <= 10||1881
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||56871
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||124932
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||117619
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||223647
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 7||2148
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||4255
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||109768
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 6||4873
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||179020
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||226176
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Flow_rate >= 15 AND Flow_rate <= 46 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||169
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||129504
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||4525
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||291630
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||31707
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||57454
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||143904
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||255507
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||355286
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 9||10267
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||344712
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110080
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 8 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 8||336
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||113648
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||204313
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||213978
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 5||17704
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||1866
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||151018
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 9 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||447
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||264203
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||68321
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 5||14536
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||70798
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 9 AND R5 >= 5 AND R5 <= 8 AND R7 >= 4 AND R7 <= 7||7985
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||125007
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||313878
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||110519
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||291630
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||1088
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 7 AND Flow_rate <= 38 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||107
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||117881
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||167504
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||226176
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 7 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 7||3124
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||62397
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 4||60693
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||155541
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 8||17048
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 7||19779
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||63234
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||91931
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||14131
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||62397
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||264203
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||121266
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||28269
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||29410
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 9||1205
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||178581
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||8133
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||351332
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||11053
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||40324
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||118514
SELECT COUNT(*) FROM climate WHERE Temperature >= 6 AND Temperature <= 27 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 10 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 9||555
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||50392
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||882
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||14964
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||120745
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 8 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||773
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||40623
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 5||275651
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Flow_rate >= 4 AND Flow_rate <= 35 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 8||791
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||52896
SELECT COUNT(*) FROM climate WHERE Temperature >= 5 AND Temperature <= 26 AND R1 >= 5 AND R1 <= 9 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||1400
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||110519
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||6666
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||818
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||179020
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND R1 >= 5 AND R1 <= 8 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 7||8663
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||167504
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||41740
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||51586
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||108914
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||313878
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND R1 >= 5 AND R1 <= 10 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 7||28201
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||245976
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||17715
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||2485
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170586
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||2522
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||25973
SELECT COUNT(*) FROM climate WHERE Temperature >= 7 AND Temperature <= 28 AND Flow_rate >= 3 AND Flow_rate <= 34 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 9 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||118
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||15684
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||164215
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||62397
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||125441
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||1291
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70384
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||155627
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||286849
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||68630
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 5||46852
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||245976
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||15055
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||135897
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND R1 >= 5 AND R1 <= 9 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||1497
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 9||1831
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Humidity >= 9 AND Humidity <= 33 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||1020
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110080
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Temperature >= 5 AND Temperature <= 26 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 8 AND R7 >= 5 AND R7 <= 8||594
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||147444
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 5 AND R1 <= 9 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||690
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 13 AND Flow_rate <= 44 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 8||289
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 9 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||2610
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||192895
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||61983
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||217918
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||38618
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||12
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||46466
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||2536
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 1 AND Humidity <= 25 AND Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||5003
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||28074
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||275106
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||170147
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||108800
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||68432
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||224297
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||163286
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||155541
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||91931
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||41526
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||147444
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 5 AND R7 >= 2 AND R7 <= 7||88610
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND R1 >= 5 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 7||9728
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||213283
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 9 AND R5 >= 6 AND R5 <= 11 AND R7 >= 5 AND R7 <= 9||232
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||87753
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||56476
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 7||22876
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||101408
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||4396
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||256145
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||104531
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||213283
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||223647
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||83511
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 5 AND Humidity <= 29 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||24328
SELECT COUNT(*) FROM climate WHERE Temperature >= 5 AND Temperature <= 26 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 9 AND R5 >= 5 AND R5 <= 10 AND R7 >= 4 AND R7 <= 8||7425
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 8||1208
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||33449
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||245976
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||2191
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||11110
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||252596
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||192895
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||336288
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||27267
SELECT COUNT(*) FROM climate WHERE Humidity >= 8 AND Humidity <= 32 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||2
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||43064
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 7||77496
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||155541
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||70384
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||11266
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||256145
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||155541
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||289260
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||28746
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||109353
SELECT COUNT(*) FROM climate WHERE Temperature >= 7 AND Temperature <= 28 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||3260
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||229000
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||2233
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 8 AND R7 >= 5 AND R7 <= 9||444
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||286849
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 4||155541
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||216714
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||70384
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||313878
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||17292
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||204313
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 1 AND Humidity <= 25 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||1083
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||681
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||213978
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 12 AND Flow_rate <= 43 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||6
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||79072
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||208688
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||87115
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 7 AND R5 >= 4 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||17138
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||22591
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||1603
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||62397
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 10 AND Flow_rate <= 41 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||1094
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||134501
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 4 AND Flow_rate <= 35 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||3010
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||197060
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||3913
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||79333
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||10488
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||158969
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||58317
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 4 AND R7 <= 9||5477
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 7 AND R5 >= 4 AND R5 <= 8 AND R7 >= 4 AND R7 <= 8||3705
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 7 AND R5 >= 5 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||4037
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||103904
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||178581
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||33659
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 10 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||249
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 10||681
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||203609
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 7||38841
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||143479
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||111834
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||146516
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||56476
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||197060
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 8||6251
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||217918
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||4038
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170147
SELECT COUNT(*) FROM climate WHERE Temperature >= 6 AND Temperature <= 27 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 5||20014
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||13531
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||344711
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||17129
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||2720
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 8||1682
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 6 AND R1 <= 10 AND R5 >= 6 AND R5 <= 11 AND R7 >= 5 AND R7 <= 8||1233
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||4162
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||14067
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 6||8475
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 14 AND Flow_rate <= 45 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||6
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 6||11778
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||204313
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||162510
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||129875
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||256145
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||101605
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Temperature >= 5 AND Temperature <= 26 AND Flow_rate >= 4 AND Flow_rate <= 35 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 9 AND R7 >= 5 AND R7 <= 8||474
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70798
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||50417
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||12838
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||48323
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||275106
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||31998
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 6||226176
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||234218
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||101605
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||283331
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||109353
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110519
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||155627
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Humidity >= 6 AND Humidity <= 30 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||30855
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||42989
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||129719
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||50796
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||92957
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110519
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 9||3429
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||15088
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 6||22184
SELECT COUNT(*) FROM climate WHERE Time >= 4 AND Time <= 16 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||53759
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||70384
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 10 AND Temperature <= 31 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||2297
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 8||28746
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND R1 >= 5 AND R1 <= 8 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 9||1232
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||336288
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||110080
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||279077
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||185328
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Flow_rate >= 6 AND Flow_rate <= 37 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||1680
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||167504
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||222835
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||91931
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||108914
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||7976
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||190748
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 5 AND Flow_rate <= 36 AND R1 >= 6 AND R1 <= 9 AND R5 >= 6 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||1046
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||11565
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 6||26794
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||3429
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 6 AND Flow_rate <= 37 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 10||304
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 0 AND Humidity <= 24 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||46403
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND Flow_rate >= 16 AND Flow_rate <= 47 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||1608
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Humidity >= 2 AND Humidity <= 26 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||15181
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 9 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 9||624
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||223858
SELECT COUNT(*) FROM climate WHERE Temperature >= 3 AND Temperature <= 24 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||11359
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||83283
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||20510
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 7 AND R5 >= 5 AND R5 <= 8 AND R7 >= 4 AND R7 <= 7||2240
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||7420
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||125007
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 6 AND Flow_rate <= 37 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 4 AND R7 <= 9||1253
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||135849
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||29400
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 6 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 8||11521
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||167504
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||61983
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||4097
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||104343
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||11902
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||135074
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||15554
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 5 AND R7 >= 3 AND R7 <= 7||14792
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||79369
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||146150
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 3 AND Temperature <= 24 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 6||21951
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||102325
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||229000
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 4||42115
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||49863
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||224297
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 2 AND R1 <= 7 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 6||77496
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||20172
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 6||16274
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||344711
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||118953
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 7||5183
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 6||17564
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 5 AND Temperature <= 26 AND R1 >= 6 AND R1 <= 9 AND R5 >= 5 AND R5 <= 10 AND R7 >= 5 AND R7 <= 10||604
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 3 AND Flow_rate <= 34 AND R1 >= 4 AND R1 <= 7 AND R5 >= 4 AND R5 <= 9 AND R7 >= 3 AND R7 <= 6||14329
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||230448
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 10 AND Flow_rate <= 41 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 6||3810
SELECT COUNT(*) FROM climate WHERE Temperature >= 1 AND Temperature <= 22 AND Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 6||25469
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||131808
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND R1 >= 5 AND R1 <= 8 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 10||1313
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||252596
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 5 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||14067
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||50417
SELECT COUNT(*) FROM climate WHERE Time >= 3 AND Time <= 15 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 4||79252
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||155627
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||73926
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||333918
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 2 AND R7 <= 5||49865
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||98897
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||52604
SELECT COUNT(*) FROM climate WHERE Temperature >= 9 AND Temperature <= 30 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 10 AND R5 >= 5 AND R5 <= 8 AND R7 >= 5 AND R7 <= 9||324
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||110080
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||234218
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Temperature >= 3 AND Temperature <= 24 AND R1 >= 4 AND R1 <= 7 AND R5 >= 3 AND R5 <= 6 AND R7 >= 4 AND R7 <= 7||3425
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||179020
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND Flow_rate >= 7 AND Flow_rate <= 38 AND Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 5 AND R1 <= 9 AND R5 >= 4 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||213
SELECT COUNT(*) FROM climate WHERE Humidity >= 2 AND Humidity <= 26 AND R1 >= 3 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||47565
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||113648
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Humidity >= 2 AND Humidity <= 26 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||25846
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||1921
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||224297
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||130360
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||144724
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||144724
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||110080
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||114747
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 10 AND R5 >= 6 AND R5 <= 9 AND R7 >= 5 AND R7 <= 9||681
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||72929
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 0 AND Temperature <= 21 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 4||1
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||233779
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 4 AND Heater_voltage <= 14 AND R1 >= 4 AND R1 <= 9 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||860
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||18278
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||40183
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 0 AND Flow_rate <= 31 AND R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 5||79712
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||65315
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||103904
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||256550
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||192895
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 4 AND R7 >= 2 AND R7 <= 5||20637
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||29529
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 2 AND R7 <= 5||6953
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170147
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 5 AND R7 >= 2 AND R7 <= 5||48859
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||265131
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 12 AND Flow_rate <= 43 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 9 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||236
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||118514
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||53342
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 5 AND R1 <= 8 AND R5 >= 6 AND R5 <= 11 AND R7 >= 5 AND R7 <= 8||373
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||333918
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||255507
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||11110
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||190525
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||223647
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 5||230448
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 4||291630
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 4 AND R1 <= 8 AND R5 >= 3 AND R5 <= 8 AND R7 >= 3 AND R7 <= 8||2462
SELECT COUNT(*) FROM climate WHERE Time >= 0 AND Time <= 12 AND Humidity >= 1 AND Humidity <= 25 AND Temperature >= 16 AND Temperature <= 37 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||1069
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||104343
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||144724
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 6||70798
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||170586
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 1 AND Flow_rate <= 32 AND R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||83258
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 11 AND Flow_rate <= 42 AND Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 7 AND R5 >= 3 AND R5 <= 8 AND R7 >= 4 AND R7 <= 9||1612
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||110080
SELECT COUNT(*) FROM climate WHERE Time >= 5 AND Time <= 17 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 3 AND R1 <= 7 AND R5 >= 2 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||1348
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 4 AND R1 <= 9 AND R5 >= 4 AND R5 <= 7 AND R7 >= 3 AND R7 <= 7||52772
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||100823
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 7 AND R7 >= 3 AND R7 <= 8||15708
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 4||185328
SELECT COUNT(*) FROM climate WHERE Humidity >= 0 AND Humidity <= 24 AND Temperature >= 13 AND Temperature <= 34 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||267
SELECT COUNT(*) FROM climate WHERE Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||53770
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 3 AND R7 >= 0 AND R7 <= 3||5703
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 5 AND R7 >= 0 AND R7 <= 3||289260
SELECT COUNT(*) FROM climate WHERE Humidity >= 4 AND Humidity <= 28 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 1 AND R1 <= 4 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||55580
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND R1 >= 2 AND R1 <= 7 AND R5 >= 2 AND R5 <= 5 AND R7 >= 3 AND R7 <= 8||11560
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||144724
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 2 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||4387
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 5 AND R5 >= 2 AND R5 <= 7 AND R7 >= 1 AND R7 <= 4||38157
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 0 AND R5 <= 3 AND R7 >= 1 AND R7 <= 6||213978
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND Temperature >= 9 AND Temperature <= 30 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 3 AND R1 <= 8 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||11378
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 2 AND Flow_rate <= 33 AND Heater_voltage >= 5 AND Heater_voltage <= 15 AND R1 >= 6 AND R1 <= 11 AND R5 >= 5 AND R5 <= 9 AND R7 >= 5 AND R7 <= 10||300
SELECT COUNT(*) FROM climate WHERE Humidity >= 5 AND Humidity <= 29 AND Temperature >= 0 AND Temperature <= 21 AND R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||52608
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||184596
SELECT COUNT(*) FROM climate WHERE Humidity >= 12 AND Humidity <= 36 AND Temperature >= 1 AND Temperature <= 22 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 7 AND R7 >= 2 AND R7 <= 5||25040
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||286849
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||204313
SELECT COUNT(*) FROM climate WHERE Time >= 2 AND Time <= 14 AND Temperature >= 3 AND Temperature <= 24 AND Flow_rate >= 4 AND Flow_rate <= 35 AND Heater_voltage >= 2 AND Heater_voltage <= 12 AND R1 >= 2 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 3 AND R7 <= 7||504
SELECT COUNT(*) FROM climate WHERE Flow_rate >= 9 AND Flow_rate <= 40 AND Heater_voltage >= 0 AND Heater_voltage <= 10 AND R1 >= 1 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 5||5967
SELECT COUNT(*) FROM climate WHERE Humidity >= 3 AND Humidity <= 27 AND R1 >= 3 AND R1 <= 8 AND R5 >= 4 AND R5 <= 9 AND R7 >= 4 AND R7 <= 8||14131
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||204313
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||203609
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 0 AND R7 <= 4||91931
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 6 AND R7 >= 0 AND R7 <= 3||108929
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 4 AND R5 >= 1 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||118514
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 5||203609
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 5 AND R5 >= 0 AND R5 <= 4 AND R7 >= 0 AND R7 <= 3||283331
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 5 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 4||208688
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 4 AND R5 >= 2 AND R5 <= 5 AND R7 >= 1 AND R7 <= 5||11
SELECT COUNT(*) FROM climate WHERE R1 >= 1 AND R1 <= 4 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||103904
SELECT COUNT(*) FROM climate WHERE Humidity >= 10 AND Humidity <= 34 AND Flow_rate >= 2 AND Flow_rate <= 33 AND R1 >= 2 AND R1 <= 7 AND R5 >= 3 AND R5 <= 7 AND R7 >= 2 AND R7 <= 7||24960
SELECT COUNT(*) FROM climate WHERE R1 >= 0 AND R1 <= 3 AND R5 >= 1 AND R5 <= 4 AND R7 >= 1 AND R7 <= 5||61983
SELECT COUNT(*) FROM climate WHERE Time >= 1 AND Time <= 13 AND R1 >= 2 AND R1 <= 6 AND R5 >= 1 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||121266
SELECT COUNT(*) FROM climate WHERE Humidity >= 1 AND Humidity <= 25 AND Heater_voltage >= 1 AND Heater_voltage <= 11 AND R1 >= 1 AND R1 <= 6 AND R5 >= 2 AND R5 <= 6 AND R7 >= 1 AND R7 <= 5||4207
SELECT COUNT(*) FROM climate WHERE Temperature >= 2 AND Temperature <= 23 AND R1 >= 3 AND R1 <= 8 AND R5 >= 2 AND R5 <= 6 AND R7 >= 2 AND R7 <= 6||95332
SELECT COUNT(*) FROM climate WHERE Heater_voltage >= 3 AND Heater_voltage <= 13 AND R1 >= 3 AND R1 <= 6 AND R5 >= 3 AND R5 <= 6 AND R7 >= 3 AND R7 <= 6||2928
